from sanz import sanzexde

sanz = sanzexde

print(sanz)
